﻿using PilotProject.DAL;
using PilotProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace PilotProject.Controllers
{
    public class CompanyRepresentativeController : Controller
    {
        CompanyRepresentativeOperations companyrepoperation = new CompanyRepresentativeOperations();
        // GET: Companys Representatives
        public ActionResult Index()
        {

            return View(companyrepoperation.Get());
        }
        //// GET: CompanyRepresentative/FindById/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var customer = companyrepoperation.FindById(id.Value).FirstOrDefault();
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View("Details", customer);
        }
        //// GET: CompanyRepresentative/FindById/5
        public ActionResult FindById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var customer = companyrepoperation.FindById(id.Value);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View("Index", customer);
        }
        //// GET: CompanyRepresentative/FindByName/John
        public ActionResult FindByName(string name)
        {
            if (name == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var companyRep = companyrepoperation.FindByName(name);
            if (companyRep == null)
            {
                return HttpNotFound();
            }
            return View("Index", companyRep);
        }
        public ActionResult FindByCompanyId(int? companyid)
        {
            if (companyid == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var companyReps = companyrepoperation.FindByCompanyId(companyid.Value);
            if (companyReps == null)
            {
                return HttpNotFound();
            }
            return View("Index", companyReps);
        }
        //// POST: CompanyRepresentative/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CompanyRepresentative companyRep)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    companyrepoperation.Create(companyRep);
                    return View("Index", companyrepoperation.companyRepsList);
                }
            }
            catch (Exception ex)
            {

                ModelState.AddModelError("", "Unable to save changes.");
            }
            return View();
        }


        public ActionResult Create()
        {

            return View();
        }
        [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            try
            {
                var companyRep = companyrepoperation.Edit(id.Value);
                return View("Edit", companyRep);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Unable to read.");
            }


            return View();
        }
        //// POST: CompanyRepresentative/Edit/5
        [HttpPost, ActionName("EditPost")]
        [ValidateAntiForgeryToken]
        public ActionResult Update(int? id)
        {


            return View();
        }
        protected override void Dispose(bool disposing)
        {
            //db.Dispose();
            base.Dispose(disposing);
        }

    }
}