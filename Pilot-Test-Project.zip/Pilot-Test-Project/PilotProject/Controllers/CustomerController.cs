﻿using PilotProject.DAL;
using PilotProject.Models;
using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
//using PilotProject.DAL;
//using PilotProject.Models;
//using PilotProject.ViewModels;

namespace PilotProject.Controllers
{
    public class CustomerController : Controller
    {
        CustomerOperations customoperation = new CustomerOperations();
        // GET: Customers
        public ActionResult Index()
        {
                  
            return View(customoperation.Get());
        }
        //// GET: Cutsomer/FindById/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var customer = customoperation.FindById(id.Value).FirstOrDefault();
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View("Details", customer);
        }
        //// GET: Cutsomer/FindById/5
        public ActionResult FindById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var customer =customoperation.FindById(id.Value);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View("Index",customer);
        }
        //// GET: Cutsomer/FindByName/John
        public ActionResult FindByName(string name)
        {
            if (name == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var customer = customoperation.FindByName(name);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View("Index",customer);
        }

        //// POST: Customer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Customer customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    customoperation.Create(customer);                 
                    return View("Index", customoperation.customersList);
                }
            }
            catch (Exception ex)
            {
               
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            return View();
        }


        public ActionResult Create()
        {

            return View();
        }
        [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
           
               try
                {
                     var customer = customoperation.Edit(id.Value);
                     return View("Edit", customer);
                 }
                catch (Exception ex)
                {                    
                    ModelState.AddModelError("", "Unable to read.");
                }
            

            return View();
        }
        //// POST: Cutsomer/Edit/5
        [HttpPost, ActionName("EditPost")]
        [ValidateAntiForgeryToken]
        public ActionResult Update(int? id)
        {
                     

            return View();
        }
        protected override void Dispose(bool disposing)
        {
            //db.Dispose();
            base.Dispose(disposing);
        }

    }
}
