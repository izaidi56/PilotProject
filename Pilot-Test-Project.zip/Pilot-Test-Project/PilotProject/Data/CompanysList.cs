﻿using PilotProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PilotProject.Data
{
    public static class CompanysList
    {
       
            public static List<Company> companys = new List<Company>
            {
                new Company { Id=1,Name = "Company1",     StreetNo = 350000,
                    StreetName = "Irvine Ave",City="Irvine"
                    },
                new Company { Id=2,Name = "Company2",     StreetNo = 550000,
                    StreetName = "Irvine Ave",City="Irvine"
                    },

            };
        
    }
}