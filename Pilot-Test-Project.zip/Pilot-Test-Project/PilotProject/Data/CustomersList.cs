﻿using PilotProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PilotProject.Data
{
    public static class CustomersList
    {
        public static List<Customer> customers = new List<Customer>
            {
                new Customer { Id=1,Name = "Customer1",     StreetNo = 350000,
                    StreetName = "Irvine Ave",City="Irvine",Notes="notes",
                     Representative=CompanyRepresentativesList.companyReps.Where(x=>x.Id==1).First()
                    },
                new Customer { Id=2,Name = "Customer2",     StreetNo = 550000,
                    StreetName = "Irvine Ave",City="Irvine",Notes="notes",
                    Representative=CompanyRepresentativesList.companyReps.Where(x=>x.Id==2).First()
                    },
              
            };
    }

}