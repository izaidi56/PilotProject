﻿using PilotProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PilotProject.Data
{
    public static class CompanyRepresentativesList
    {
        public static List<CompanyRepresentative> companyReps = new List<CompanyRepresentative>
            {
                new CompanyRepresentative { Id=1,Name = "CompanyRep1",Title="title1",     StreetNo = 350000,PhoneNo="4086009973",
                    StreetName = "Irvine Ave",City="Irvine",
                     Company=CompanysList.companys.Where(x=>x.Id==1).First()
                    },
                new CompanyRepresentative { Id=2,Name = "CompanyRep2",Title="title2",     StreetNo = 550000,PhoneNo="5086009973",
                    StreetName = "John Av",City="Irvine",
                    Company=CompanysList.companys.Where(x=>x.Id==2).First()
                    },
                 new CompanyRepresentative { Id=3,Name = "CompanyRep3",Title="title3",     StreetNo = 1550000,PhoneNo="6086009973",
                    StreetName = "Bryan Ave",City="Irvine",
                    Company=CompanysList.companys.Where(x=>x.Id==2).First()
                    },

            };
    }
}