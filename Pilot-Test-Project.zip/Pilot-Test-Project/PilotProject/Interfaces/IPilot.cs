﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PilotProject.Interfaces
{
    public interface IPilot
    {
        IEnumerable<object> Get();
        object Detail();
        IEnumerable<object> FindById(int id);
        IEnumerable<object> FindByName(string name);
        void Create(object o);
        void Update(object o);
        void Delete(object o);
        object Edit(int id);
    }
}