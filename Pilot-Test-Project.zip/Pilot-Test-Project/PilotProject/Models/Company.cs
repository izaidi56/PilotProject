﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace PilotProject.Models
{
    public class Company
    {
        
        public int? Id { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "Please enter street name.")]
        [Column("StreetName")]
        [Display(Name = "StreetName")]
        public string StreetName { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "City")]
        public string City { get; set; }

        [Display(Name = "StreetNo")]
        public int? StreetNo { get; set; }

    }
}