﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace PilotProject.Models
{
    public class Customer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]        
        public int Id { get; set; }
        public virtual CompanyRepresentative Representative { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Name")]
        public string Name { get; set; }
        
        [StringLength(50)]
        [Display(Name = "Notes")]
        public string Notes { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "Please enter street name.")]
        [Column("StreetName")]
        [Display(Name = "StreetName")]
        public string StreetName { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "City")]
        public string City { get; set; }

        [Display(Name = "StreetNo")]
        public int? StreetNo { get; set; }
    }
}