﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace PilotProject.Models
{
    public class CompanyRepresentative
    {
        public int? Id { get; set; }
        public virtual Company Company { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "PhoneNo")]
        public string PhoneNo { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "Please enter street name.")]
        [Column("StreetName")]
        [Display(Name = "StreetName")]
        public string StreetName { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "City")]
        public string City { get; set; }

        [Display(Name = "StreetNo")]
        public int? StreetNo { get; set; }

    }
}