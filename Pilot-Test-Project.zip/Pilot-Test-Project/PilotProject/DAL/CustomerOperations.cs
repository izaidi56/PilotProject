﻿using PilotProject.Interfaces;
using PilotProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PilotProject.DAL
{
    public class CustomerOperations : IPilot
    {
        public IEnumerable<Customer> customersList = HttpContext.Current.Application["customers"] as IEnumerable<Customer>;
        public void Create(object o)
        {
            var customer=(Customer) o;
            var customerlst = customersList.ToList();
            customerlst.Add(o as Customer);
            customersList=customerlst.AsEnumerable();
        }

        public void Delete(object o)
        {
            throw new NotImplementedException();
        }

        public object Detail()
        {
            throw new NotImplementedException();
        }

        public object Edit(int id)
        {
            return customersList.Where(x => x.Id == id).FirstOrDefault();
        }

        public IEnumerable<object> FindById(int id)
        {   
            return customersList.Where(x=>x.Id==id);
        }

        public IEnumerable<object> FindByName(string name)
        {
            return customersList.Where(x => x.Name.ToLower() == name.ToLower());
        }

        public IEnumerable<object> Get()
        {
            var customersList = HttpContext.Current.Application["customers"] as IEnumerable<Customer>;
            IEnumerable<Customer> customers = customersList;
            return customers;
                
        }

        public void Update(object o)
        {
            throw new NotImplementedException();
        }

       
    }
}