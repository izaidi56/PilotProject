﻿using PilotProject.Interfaces;
using PilotProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PilotProject.DAL
{
    public class CompanyOperations : IPilot
    {
        public IEnumerable<Company> companysList = HttpContext.Current.Application["companys"] as IEnumerable<Company>;
        public void Create(object o)
        {
            throw new NotImplementedException();
        }

        public void Delete(object o)
        {
            throw new NotImplementedException();
        }

        public object Detail()
        {
            throw new NotImplementedException();
        }

        public object Edit(int id)
        {
                return companysList.Where(x => x.Id == id).FirstOrDefault();
        }
        

        public IEnumerable<object> FindById(int id)
        {
            return companysList.Where(x => x.Id == id);
        }

        public IEnumerable<object> FindByName(string name)
        {
            return companysList.Where(x => x.Name.ToLower() == name.ToLower());
        }

        public IEnumerable<object> Get()
        {
            var companysList = (Company)HttpContext.Current.Application["companys"] as IEnumerable<Company>;
            IEnumerable<Company> companys = companysList;
            return companys;
        }

        public void Update(object o)
        {
            throw new NotImplementedException();
        }
    }
}