﻿using PilotProject.Interfaces;
using PilotProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PilotProject.DAL
{
    public class CompanyRepresentativeOperations : IPilot
    {
        public IEnumerable<CompanyRepresentative> companyRepsList = HttpContext.Current.Application["companyrepresentatives"] as IEnumerable<CompanyRepresentative>;
        public void Create(object o)
        {
            var companyReps = (CompanyRepresentative)o;
            var compsRepsLst = companyRepsList.ToList();
            compsRepsLst.Add(o as CompanyRepresentative);
            companyRepsList = compsRepsLst.AsEnumerable();
        }
        public object Edit(int id)
        {
            return companyRepsList.Where(x => x.Id == id).FirstOrDefault();
        }
        public void Delete(object o)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<object> FindById(int id)
        {
            return companyRepsList.Where(x => x.Id == id);
        }
        public IEnumerable<object> FindByCompanyId(int companyid)
        {
            return companyRepsList.Where(x => x.Company.Id == companyid);
        }
        public IEnumerable<object> FindByName(string name)
        {
            return companyRepsList.Where(x => x.Name.ToLower() == name.ToLower());
        }     

        public void Update(object o)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<object> Get()
        {
            var companyrepsList = HttpContext.Current.Application["companyrepresentatives"] as IEnumerable<CompanyRepresentative>;
            IEnumerable<CompanyRepresentative> companyReps = companyrepsList;
            return companyReps;            
        }

        public object Detail()
        {
            throw new NotImplementedException();
        }
    }
}